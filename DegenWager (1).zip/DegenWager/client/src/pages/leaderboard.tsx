import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Users, DollarSign, RotateCcw, Crown, Medal, Award, User, Star, Zap, Shield, Gem, Calendar, Clock, Filter } from "lucide-react";
import { SiDiscord, SiKick, SiTwitch, SiYoutube, SiX, SiInstagram, SiTelegram, SiReddit } from "react-icons/si";
import { TbRainbow as SiRain } from "react-icons/tb";
import { Button } from "@/components/ui/button";
import type { LeaderboardResponse } from "@shared/schema";

export default function Leaderboard() {
  const [timeFilter, setTimeFilter] = useState<'day' | 'week' | 'month'>('month');

  const { 
    data: leaderboardData, 
    isLoading, 
    error, 
    refetch 
  } = useQuery<LeaderboardResponse>({
    queryKey: ['/api/wagers', timeFilter],
  });

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-400 rank-badge-glow" />;
    if (rank === 2) return <Trophy className="w-6 h-6 text-gray-300 rank-badge-glow" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-orange-400 rank-badge-glow" />;
    if (rank <= 5) return <Star className="w-5 h-5 text-purple-400" />;
    if (rank <= 10) return <Gem className="w-5 h-5 text-blue-400" />;
    return <span className="text-sm font-bold">{rank}</span>;
  };

  const getRankBadgeClass = (rank: number) => {
    if (rank === 1) return "bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 text-black shadow-lg shadow-yellow-400/50";
    if (rank === 2) return "bg-gradient-to-br from-gray-300 via-gray-400 to-gray-500 text-black shadow-lg shadow-gray-400/50";
    if (rank === 3) return "bg-gradient-to-br from-orange-400 via-orange-500 to-orange-600 text-black shadow-lg shadow-orange-400/50";
    if (rank <= 5) return "bg-gradient-to-br from-purple-500 to-purple-600 text-white shadow-lg shadow-purple-500/30";
    if (rank <= 10) return "bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30";
    return "bg-gradient-to-br from-gray-600 to-gray-700 text-white";
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // High-quality anime avatar system
  const getPlayerAvatar = (username: string) => {
    // Use adventurer-neutral style for anime-like characters with better quality
    return `https://api.dicebear.com/8.x/adventurer-neutral/svg?seed=${encodeURIComponent(username)}&backgroundColor=1a1a2e,16213e,0f0f23&skinColor=f8cecc,f5c2c7,fdbcb4,ecad80&hairColor=724133,a55728,8b4513,2c1b18,b58143&clothesColor=262e33,5199e4,25557c,65c9ff,3c4f5c,ff6b6b,ff8e53&eyesColor=26c0b0,4299e1,48bb78&mouthColor=ff6b6b,d63384,6f42c1&scale=120&radius=20&backgroundType=gradientLinear`;
  };

  // Platform icon detection with premium styling
  const getPlatformIcon = (username: string) => {
    const lowerName = username.toLowerCase();
    
    if (lowerName.includes('discord') || lowerName.includes('disc')) {
      return <SiDiscord className="w-5 h-5 text-indigo-400 platform-icon" />;
    }
    if (lowerName.includes('kick')) {
      return <SiKick className="w-5 h-5 text-green-400 platform-icon" />;
    }
    if (lowerName.includes('twitch') || lowerName.includes('ttv')) {
      return <SiTwitch className="w-5 h-5 text-purple-400 platform-icon" />;
    }
    if (lowerName.includes('youtube') || lowerName.includes('yt')) {
      return <SiYoutube className="w-5 h-5 text-red-400 platform-icon" />;
    }
    if (lowerName.includes('twitter') || lowerName.includes('tw') || lowerName.includes('x.com')) {
      return <SiX className="w-5 h-5 text-blue-400 platform-icon" />;
    }
    if (lowerName.includes('instagram') || lowerName.includes('ig')) {
      return <SiInstagram className="w-5 h-5 text-pink-400 platform-icon" />;
    }
    if (lowerName.includes('telegram') || lowerName.includes('tg')) {
      return <SiTelegram className="w-5 h-5 text-blue-500 platform-icon" />;
    }
    if (lowerName.includes('reddit')) {
      return <SiReddit className="w-5 h-5 text-orange-500 platform-icon" />;
    }
    if (lowerName.includes('rain') || lowerName.includes('rainbet')) {
      return <SiRain className="w-5 h-5 text-cyan-400 platform-icon" />;
    }
    
    // Default gaming icon
    return <Shield className="w-5 h-5 text-primary-gold platform-icon" />;
  };

  // Enhanced tier styling
  const getTierStyling = (rank: number) => {
    if (rank === 1) return "ring-4 ring-yellow-400/50 bg-gradient-to-br from-yellow-50/10 to-yellow-100/5";
    if (rank === 2) return "ring-4 ring-gray-400/50 bg-gradient-to-br from-gray-50/10 to-gray-100/5";
    if (rank === 3) return "ring-4 ring-orange-400/50 bg-gradient-to-br from-orange-50/10 to-orange-100/5";
    if (rank <= 5) return "ring-2 ring-purple-400/30 bg-gradient-to-br from-purple-50/5 to-purple-100/5";
    if (rank <= 10) return "ring-2 ring-blue-400/30 bg-gradient-to-br from-blue-50/5 to-blue-100/5";
    return "";
  };

  return (
    <div className="min-h-screen bg-dark-bg relative overflow-hidden">
      {/* Floating Particles Background */}
      <div className="floating-particles">
        {Array.from({ length: 25 }, (_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 15}s`,
              animationDuration: `${15 + Math.random() * 10}s`,
            }}
          />
        ))}
      </div>
      
      <section className="min-h-screen py-12 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Enhanced Header */}
          <div className="text-center mb-16 relative">
            <div className="relative inline-block mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-primary-gold to-secondary-gold rounded-2xl shadow-2xl shadow-primary-gold/30 mb-6 leaderboard-glow">
                <Trophy className="text-dark-bg h-10 w-10" />
              </div>
              <div className="absolute -top-1 -right-1">
                <Star className="w-6 h-6 text-yellow-300 animate-pulse" />
              </div>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-black mb-6 gg-logo tracking-tight" data-testid="leaderboard-title">
              🏆 LEADERBOARDS 🏆
            </h1>
            <p className="text-2xl text-text-secondary mb-8 font-light">Top performers and their epic achievements</p>
            
            {/* Enhanced Date Information with Refresh */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
              <div className="glass-surface rounded-xl p-4 leaderboard-glow">
                <p className="text-text-secondary text-sm mb-1">Live Data - Updated Today:</p>
                <p className="text-primary-gold font-bold">{new Date().toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</p>
              </div>
              
              <Button 
                onClick={() => refetch()}
                className="bg-gradient-to-r from-primary-gold to-secondary-gold hover:from-secondary-gold hover:to-primary-gold text-dark-bg font-bold px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
                disabled={isLoading}
              >
                <RotateCcw className={`mr-2 h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} />
                {isLoading ? 'Refreshing...' : 'Refresh Data'}
              </Button>
            </div>
          </div>

          {/* Time Filter & Main Content Layout */}
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Time Filter Sidebar */}
            <div className="lg:w-80 flex-shrink-0">
              <div className="glass-surface rounded-2xl p-6 sticky top-8">
                <div className="flex items-center gap-3 mb-6">
                  <Filter className="w-6 h-6 text-primary-gold" />
                  <h3 className="text-xl font-bold text-primary-gold">Time Period</h3>
                </div>
                
                <div className="space-y-3">
                  {[
                    { key: 'day' as const, label: 'Today', icon: Clock, desc: 'Last 24 hours' },
                    { key: 'week' as const, label: 'This Week', icon: Calendar, desc: 'Last 7 days' },
                    { key: 'month' as const, label: 'This Month', icon: Calendar, desc: 'Last 30 days' }
                  ].map(({ key, label, icon: Icon, desc }) => (
                    <button
                      key={key}
                      onClick={() => setTimeFilter(key)}
                      className={`w-full p-4 rounded-xl text-left transition-all duration-300 ${
                        timeFilter === key
                          ? 'bg-gradient-to-r from-primary-gold to-secondary-gold text-dark-bg shadow-lg scale-105'
                          : 'bg-dark-surface/50 hover:bg-dark-surface text-text-primary hover:scale-102'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={`w-5 h-5 ${timeFilter === key ? 'text-dark-bg' : 'text-primary-gold'}`} />
                        <div>
                          <div className={`font-semibold ${timeFilter === key ? 'text-dark-bg' : 'text-text-primary'}`}>
                            {label}
                          </div>
                          <div className={`text-sm ${timeFilter === key ? 'text-dark-bg/70' : 'text-text-secondary'}`}>
                            {desc}
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Filter Info */}
                <div className="mt-6 p-4 bg-dark-surface/30 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4 text-green-400" />
                    <span className="text-sm font-semibold text-green-400">Real-time Data</span>
                  </div>
                  <p className="text-xs text-text-secondary">
                    Rankings update automatically based on your selected time period for accurate leaderboards.
                  </p>
                </div>
              </div>
            </div>

            {/* Main Leaderboard Content */}
            <div className="flex-1">
              {/* Loading State */}
              {isLoading && (
                <div className="text-center py-12" data-testid="loading-state">
                  <div className="glass-surface rounded-xl p-8 premium-card inline-block">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-gold mx-auto mb-4"></div>
                    <p className="text-text-secondary">Loading leaderboard data...</p>
                  </div>
                </div>
              )}

              {/* Error State */}
              {error && (
                <div className="text-center py-12" data-testid="error-state">
                  <div className="glass-surface rounded-xl p-8 premium-card inline-block border-red-500/20">
                    <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 rounded-full flex items-center justify-center">
                      <Trophy className="w-8 h-8 text-red-400" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2 text-red-400">Failed to Load Data</h3>
                    <p className="text-text-secondary mb-4 max-w-md mx-auto">
                      {error instanceof Error ? error.message : "Unable to fetch leaderboard information. Please check your connection and try again."}
                    </p>
                    <Button 
                      onClick={() => refetch()}
                      data-testid="retry-button"
                      className="bg-red-500 hover:bg-red-600 transition-colors duration-300"
                      disabled={isLoading}
                    >
                      <RotateCcw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                      {isLoading ? 'Retrying...' : 'Retry'}
                    </Button>
                  </div>
                </div>
              )}

              {/* Leaderboard Content */}
              {leaderboardData && (
                <div data-testid="leaderboard-content">
                  {/* Premium Stats Cards */}
                  <div className="grid md:grid-cols-3 gap-6 mb-12">
                    <div className="glass-surface rounded-xl p-6 premium-card card-hover-effect relative overflow-hidden" data-testid="stat-total-players">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary-gold/5 to-transparent"></div>
                  <div className="relative flex items-center justify-between">
                    <div>
                      <p className="text-text-secondary text-sm font-medium mb-2 flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Total Players
                      </p>
                      <p className="text-4xl font-bold text-primary-gold">
                        {leaderboardData.totalPlayers || leaderboardData.data.length}
                      </p>
                      <p className="text-xs text-text-secondary mt-1">Active competitors</p>
                    </div>
                    <div className="p-3 bg-primary-gold/10 rounded-xl">
                      <Users className="text-primary-gold h-8 w-8" />
                    </div>
                  </div>
                </div>
                
                <div className="glass-surface rounded-xl p-6 premium-card card-hover-effect relative overflow-hidden" data-testid="stat-total-wagered">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent"></div>
                  <div className="relative flex items-center justify-between">
                    <div>
                      <p className="text-text-secondary text-sm font-medium mb-2 flex items-center gap-2">
                        <DollarSign className="w-4 h-4" />
                        Total Wagered
                      </p>
                      <p className="text-4xl font-bold text-green-400">
                        {formatCurrency(leaderboardData.totalWagered || 0)}
                      </p>
                      <p className="text-xs text-text-secondary mt-1">Combined volume</p>
                    </div>
                    <div className="p-3 bg-green-500/10 rounded-xl">
                      <DollarSign className="text-green-400 h-8 w-8" />
                    </div>
                  </div>
                </div>

                <div className="glass-surface rounded-xl p-6 premium-card card-hover-effect relative overflow-hidden" data-testid="stat-total-prizes">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent"></div>
                  <div className="relative flex items-center justify-between">
                    <div>
                      <p className="text-text-secondary text-sm font-medium mb-2 flex items-center gap-2">
                        <Award className="w-4 h-4" />
                        Potential Prizes
                      </p>
                      <p className="text-4xl font-bold text-purple-400">
                        {formatCurrency(leaderboardData.totalPrizes || (leaderboardData.totalWagered || 0) * 0.1)}
                      </p>
                      <p className="text-xs text-text-secondary mt-1">Available rewards</p>
                    </div>
                    <div className="p-3 bg-purple-500/10 rounded-xl">
                      <Award className="text-purple-400 h-8 w-8" />
                    </div>
                  </div>
                </div>
              </div>

              {leaderboardData.data.length === 0 ? (
                <div className="text-center py-16" data-testid="empty-state">
                  <div className="glass-surface rounded-xl p-12 premium-card inline-block">
                    <div className="w-24 h-24 mx-auto mb-6 bg-text-secondary/10 rounded-full flex items-center justify-center">
                      <Trophy className="text-text-secondary h-12 w-12" />
                    </div>
                    <h3 className="text-2xl font-semibold mb-4 text-text-secondary">No Players Found</h3>
                    <p className="text-text-secondary/70 mb-4">
                      No affiliate data available for the selected time period.
                    </p>
                    <p className="text-sm text-text-secondary/50">
                      Try selecting a different time period or check back later.
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  {/* Top 3 Players - Animated Cards */}
                  {leaderboardData.data.length >= 1 && (
                    <div className="mb-12">
                      <h2 className="text-2xl font-bold text-center mb-8 text-text-primary">
                        <Crown className="inline-block mr-2 h-6 w-6 text-primary-gold" />
                        TOP WAGERERS
                      </h2>
                      <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                        {leaderboardData.data.slice(0, 3).map((player, index) => (
                          <div 
                            key={player.id || index}
                            className={`premium-card card-hover-effect rounded-2xl p-6 text-center premium-shimmer stagger-animation ${getTierStyling(index + 1)} ${
                              index === 0 ? 'md:-mt-4 shadow-lg shadow-primary-gold/30' :
                              index === 1 ? 'md:mt-2' : 'md:mt-4'
                            }`}
                            style={{ animationDelay: `${index * 0.2}s` }}
                            data-testid={`top-player-${index + 1}`}
                          >
                            {/* Rank Badge with Enhanced Effects */}
                            <div className="mb-4 relative">
                              <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center shadow-2xl ${getRankBadgeClass(index + 1)}`}>
                                {getRankIcon(index + 1)}
                              </div>
                              {index === 0 && (
                                <div className="absolute -top-2 -right-2">
                                  <Star className="w-6 h-6 text-yellow-300 animate-pulse" />
                                </div>
                              )}
                            </div>
                            
                            {/* Player Avatar with Premium Effects */}
                            <div className="mb-4 relative">
                              <div className="relative inline-block">
                                <img 
                                  src={getPlayerAvatar(player.user)}
                                  alt={`${player.user} avatar`}
                                  className="w-24 h-24 mx-auto rounded-full border-4 border-primary-gold/30 shadow-2xl avatar-hover-effect"
                                />
                                <div className="absolute -bottom-1 -right-1 bg-dark-surface/90 p-1 rounded-full border-2 border-primary-gold/20">
                                  {getPlatformIcon(player.user)}
                                </div>
                              </div>
                            </div>
                            
                            {/* Player Info with Enhanced Typography */}
                            <div className="mb-4">
                              <h3 className="text-xl font-bold text-text-primary mb-2 tracking-wide">
                                {player.user || 'Anonymous Player'}
                              </h3>
                              <p className="text-text-secondary text-sm mb-2">
                                ID: #{player.id?.slice(0, 8) || 'UNKNOWN'}...
                              </p>
                              <div className="flex items-center justify-center gap-2 text-xs text-text-secondary">
                                <Zap className="w-3 h-3" />
                                <span>Rank #{index + 1}</span>
                              </div>
                            </div>
                            
                            {/* Wagered Amount with Premium Styling */}
                            <div className="bg-gradient-to-br from-dark-surface/80 to-dark-surface/60 backdrop-blur-sm rounded-xl p-4 border border-primary-gold/10">
                              <p className="text-text-secondary text-sm mb-1 flex items-center justify-center gap-1">
                                <DollarSign className="w-3 h-3" />
                                Total Wagered
                              </p>
                              <p className="text-2xl font-bold text-primary-gold mb-2">
                                {formatCurrency(player.wagered || 0)}
                              </p>
                              <div className="flex items-center justify-center gap-4 text-xs text-text-secondary">
                                <span className="flex items-center gap-1">
                                  <Trophy className="w-3 h-3" />
                                  {player.bets || 0} bets
                                </span>
                                <span className="flex items-center gap-1">
                                  <Award className="w-3 h-3" />
                                  {formatCurrency(player.prize || 0)} won
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* All Remaining Players - Enhanced Table */}
                  {leaderboardData.data.length > 3 && (
                    <div>
                      <h2 className="text-2xl font-bold mb-8 text-text-primary flex items-center justify-center">
                        <Medal className="mr-3 h-6 w-6 text-primary-gold" />
                        <span className="gg-logo">ALL COMPETITORS</span>
                        <Trophy className="ml-3 h-6 w-6 text-primary-gold" />
                      </h2>
                      <div className="glass-surface rounded-xl overflow-hidden premium-card card-hover-effect">
                        {/* Enhanced Table Header */}
                        <div className="bg-gradient-to-r from-primary-gold/15 via-secondary-gold/10 to-primary-gold/15 px-6 py-5 border-b border-primary-gold/20">
                          <div className="grid grid-cols-12 gap-4">
                            <div className="col-span-1 text-center">
                              <span className="text-primary-gold text-sm font-bold tracking-wider">RANK</span>
                            </div>
                            <div className="col-span-7 md:col-span-8">
                              <span className="text-primary-gold text-sm font-bold tracking-wider">PLAYER</span>
                            </div>
                            <div className="col-span-4 md:col-span-3 text-right">
                              <span className="text-primary-gold text-sm font-bold tracking-wider">WAGERED</span>
                            </div>
                          </div>
                        </div>

                        {/* Enhanced Table Rows - Show ALL Players */}
                        <div>
                          {leaderboardData.data.slice(3).map((player, index) => {
                            const actualRank = index + 4;
                            return (
                              <div 
                                key={player.id || index}
                                className={`grid grid-cols-12 gap-4 px-6 py-4 border-b border-dark-border/30 hover:bg-gradient-to-r hover:from-primary-gold/5 hover:to-transparent transition-all duration-300 group ${getTierStyling(actualRank)}`}
                                style={{ animationDelay: `${index * 0.05}s` }}
                                data-testid={`table-player-${actualRank}`}
                              >
                                <div className="col-span-1 text-center flex items-center justify-center">
                                  <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${getRankBadgeClass(actualRank)}`}>
                                    {getRankIcon(actualRank)}
                                  </div>
                                </div>
                                <div className="col-span-7 md:col-span-8 flex items-center">
                                  <div className="relative mr-4">
                                    <img 
                                      src={getPlayerAvatar(player.user)}
                                      alt={`${player.user} avatar`}
                                      className="w-12 h-12 rounded-full border-2 border-primary-gold/20 avatar-hover-effect shadow-lg"
                                    />
                                    <div className="absolute -bottom-1 -right-1 bg-dark-surface/90 p-0.5 rounded-full border border-primary-gold/20">
                                      {getPlatformIcon(player.user)}
                                    </div>
                                  </div>
                                  <div className="flex-1">
                                    <p className="font-bold text-text-primary group-hover:text-primary-gold transition-colors duration-300 text-lg">
                                      {player.user || 'Anonymous Player'}
                                    </p>
                                    <div className="flex items-center gap-3 text-xs text-text-secondary">
                                      <span>ID: #{player.id?.slice(0, 8) || 'UNKNOWN'}...</span>
                                      <span className="flex items-center gap-1">
                                        <Trophy className="w-3 h-3" />
                                        {player.bets || 0} bets
                                      </span>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-span-4 md:col-span-3 text-right flex flex-col justify-center">
                                  <p className="font-bold text-green-400 text-lg group-hover:text-green-300 transition-colors duration-300">
                                    {formatCurrency(player.wagered || 0)}
                                  </p>
                                  <p className="text-xs text-text-secondary flex items-center justify-end gap-1">
                                    <Award className="w-3 h-3" />
                                    {formatCurrency(player.prize || (player.wagered || 0) * 0.1)} potential
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Enhanced Footer with Stats */}
                        <div className="bg-gradient-to-r from-dark-surface/50 to-dark-surface/30 px-6 py-4 border-t border-primary-gold/20">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-text-secondary flex items-center gap-2">
                              <Users className="w-4 h-4" />
                              Showing {leaderboardData.data.length} total players
                            </span>
                            <span className="text-primary-gold font-medium">
                              Updated: {new Date().toLocaleTimeString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
