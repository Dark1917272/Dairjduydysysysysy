import React from "react";
import { Link } from "wouter";
import { Trophy, TrendingUp, Users, ExternalLink, Flame, Zap, Star, Crown } from "lucide-react";
import { SiDiscord, SiKick, SiYoutube, SiX } from "react-icons/si";
import { Button } from "@/components/ui/button";

export default function Home() {
  // Scroll animation observer
  React.useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, observerOptions);

    const animatedElements = document.querySelectorAll('.fade-in-up, .scale-in, .slide-in-left, .slide-in-right');
    animatedElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen fire-background">
      {/* Subtle Overlay */}
      <div className="fire-overlay" />

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Hero Logo with Subtle Effects */}
          <div className="mb-12 scale-in relative">
            <div className="relative inline-block">
              <h1 className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black gg-logo mb-6 hero-text-glow tracking-wider" data-testid="hero-title">
                DEGENERACY
              </h1>
              <div className="absolute -top-4 -right-4">
                <Crown className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <p className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-primary-gold mb-3 fade-in-up" data-testid="hero-subtitle">
              Stay Connected, Engage & Earn!
            </p>
            <p className="text-lg sm:text-xl md:text-2xl font-light text-orange-300 mb-8 sm:mb-12 fade-in-up">
              The Ultimate Gaming Community Experience
            </p>
          </div>

          {/* Platform Links - Updated and Current */}
          <div className="mb-16 fade-in-up">
            <h2 className="text-xl sm:text-2xl font-bold text-primary-gold mb-6 sm:mb-8 flex items-center justify-center gap-3">
              <Star className="w-8 h-8" />
              <span>FOLLOW MY SOCIALS</span>
              <Star className="w-8 h-8" />
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-6 max-w-4xl mx-auto">
              {/* Kick */}
              <a 
                href="https://kick.com/degeneracy420" 
                target="_blank" 
                rel="noopener noreferrer"
                className="glass-surface subtle-border rounded-2xl p-4 sm:p-6 premium-card group hover:scale-105 transition-all duration-300 slide-in-left flex flex-col items-center"
              >
                <SiKick className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-green-400 group-hover:text-green-300 transition-colors social-icon-glow" />
                <p className="text-white font-bold mt-2 sm:mt-3 text-xs sm:text-sm">KICK</p>
                <p className="text-green-400 text-xs hidden sm:block">Live Streams</p>
              </a>

              {/* Discord */}
              <a 
                href="https://discord.gg/MM3bjatyun" 
                target="_blank" 
                rel="noopener noreferrer"
                className="glass-surface subtle-border rounded-2xl p-4 sm:p-6 premium-card group hover:scale-105 transition-all duration-300 slide-in-left flex flex-col items-center"
              >
                <SiDiscord className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-indigo-400 group-hover:text-indigo-300 transition-colors social-icon-glow" />
                <p className="text-white font-bold mt-2 sm:mt-3 text-xs sm:text-sm">DISCORD</p>
                <p className="text-indigo-400 text-xs hidden sm:block">Community</p>
              </a>

              {/* YouTube */}
              <a 
                href="https://www.youtube.com/@BryantCarter-z4y5e" 
                target="_blank" 
                rel="noopener noreferrer"
                className="glass-surface subtle-border rounded-2xl p-4 sm:p-6 premium-card group hover:scale-105 transition-all duration-300 scale-in flex flex-col items-center"
              >
                <SiYoutube className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-red-500 group-hover:text-red-400 transition-colors social-icon-glow" />
                <p className="text-white font-bold mt-2 sm:mt-3 text-xs sm:text-sm">YOUTUBE</p>
                <p className="text-red-500 text-xs hidden sm:block">Videos</p>
              </a>

              {/* X/Twitter */}
              <a 
                href="https://x.com/Degeneracy420" 
                target="_blank" 
                rel="noopener noreferrer"
                className="glass-surface subtle-border rounded-2xl p-4 sm:p-6 premium-card group hover:scale-105 transition-all duration-300 slide-in-right flex flex-col items-center"
              >
                <SiX className="w-10 h-10 sm:w-12 sm:h-12 mx-auto text-white group-hover:text-gray-300 transition-colors social-icon-glow" />
                <p className="text-white font-bold mt-2 sm:mt-3 text-xs sm:text-sm">X / TWITTER</p>
                <p className="text-gray-400 text-xs hidden sm:block">Updates</p>
              </a>

              {/* RainBet */}
              <a 
                href="https://rainbet.com/?r=degeneracy" 
                target="_blank" 
                rel="noopener noreferrer"
                className="glass-surface subtle-border rounded-2xl p-4 sm:p-6 premium-card group hover:scale-105 transition-all duration-300 slide-in-right flex flex-col items-center"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30 group-hover:shadow-blue-400/50 transition-all duration-300 relative overflow-hidden">
                  {/* RainBet inspired design */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-50"></div>
                  <svg className="w-6 h-6 sm:w-8 sm:h-8 text-white relative z-10" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z" />
                    <circle cx="12" cy="12" r="3" fill="currentColor" className="animate-pulse" />
                  </svg>
                </div>
                <p className="text-white font-bold mt-2 sm:mt-3 text-xs sm:text-sm">RAINBET</p>
                <p className="text-blue-400 text-xs hidden sm:block">Crypto Casino</p>
              </a>
            </div>
          </div>

          {/* Main CTA Button */}
          <div className="mb-16 scale-in">
            <Link href="/leaderboard">
              <Button 
                className="bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500 hover:from-yellow-500 hover:via-orange-500 hover:to-red-500 text-white px-8 sm:px-12 md:px-16 py-4 sm:py-5 md:py-6 rounded-full text-lg sm:text-xl md:text-2xl font-black hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
                data-testid="view-leaderboard-button"
              >
                <Trophy className="mr-2 sm:mr-3 h-6 w-6 sm:h-8 sm:w-8" />
                VIEW LEADERBOARDS
              </Button>
            </Link>
          </div>

          {/* Feature Cards with Subtle Animations */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="glass-surface rounded-2xl p-8 premium-card subtle-border group hover:scale-105 transition-all duration-300 fade-in-up" data-testid="feature-0">
              <div className="relative">
                <Trophy className="text-primary-gold mb-4 h-16 w-16 mx-auto group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-primary-gold">Epic Leaderboards</h3>
              <p className="text-text-secondary text-lg">Track legendary performers and compete for massive prizes in real-time rankings</p>
            </div>
            
            <div className="glass-surface rounded-2xl p-8 premium-card subtle-border group hover:scale-105 transition-all duration-300 fade-in-up" data-testid="feature-1">
              <div className="relative">
                <TrendingUp className="text-green-400 mb-4 h-16 w-16 mx-auto group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-green-400">Live Stats</h3>
              <p className="text-text-secondary text-lg">Real-time statistics, rankings, and performance metrics updated every second</p>
            </div>
            
            <div className="glass-surface rounded-2xl p-8 premium-card subtle-border group hover:scale-105 transition-all duration-300 fade-in-up" data-testid="feature-2">
              <div className="relative">
                <Users className="text-purple-400 mb-4 h-16 w-16 mx-auto group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-purple-400">Elite Community</h3>
              <p className="text-text-secondary text-lg">Join the most competitive and passionate gaming community with exclusive perks</p>
            </div>
          </div>
        </div>
      </section>

      {/* Updated Footer with Current Information */}
      <section className="py-16 bg-gradient-to-b from-transparent via-black/50 to-dark-surface relative z-10" data-testid="disclaimer-section">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass-surface rounded-2xl p-8 subtle-border fade-in-up">
            <div className="flex items-center justify-center mb-6">
              <ExternalLink className="w-8 h-8 text-primary-gold mr-3" />
              <h3 className="text-3xl font-bold text-primary-gold">Responsible Gaming</h3>
              <ExternalLink className="w-8 h-8 text-primary-gold ml-3" />
            </div>
            <p className="text-text-secondary mb-8 leading-relaxed text-lg">
              This platform is for entertainment purposes. Gambling can be addictive and should be done responsibly. 
              We promote safe gaming practices and encourage you to set limits. If you or someone you know has a gambling problem, please seek help immediately.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a 
                href="https://www.begambleaware.org/" 
                target="_blank" 
                rel="noopener noreferrer"
                data-testid="help-link"
                className="inline-flex items-center bg-gradient-to-r from-red-500 to-orange-500 hover:from-orange-500 hover:to-red-500 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 transform hover:scale-105"
              >
                <ExternalLink className="mr-2 h-5 w-5" />
                Get Help at BeGambleAware.org
              </a>
              <p className="text-sm text-text-secondary">
                18+ Only • Play Responsibly • Know Your Limits
              </p>
            </div>
            
            {/* Current Footer Information */}
            <div className="mt-8 pt-8 border-t border-primary-gold/20">
              <p className="text-text-secondary text-sm mb-4">
                © 2025 DEGENERACY. All rights reserved.
              </p>
              <div className="flex justify-center items-center gap-4 text-xs text-text-secondary">
                <span>Last Updated: August 2025</span>
                <span>•</span>
                <span>Real-time Data</span>
                <span>•</span>
                <span>Active Community</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}