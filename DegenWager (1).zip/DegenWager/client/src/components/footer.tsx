import { ExternalLink, AlertTriangle } from "lucide-react";
import { SiKick, SiYoutube, SiInstagram, SiX, SiDiscord } from "react-icons/si";

export default function Footer() {
  const socialLinks = [
    { href: "https://kick.com/degeneracy420", icon: SiKick, color: "text-green-400", label: "Kick" },
    { href: "https://www.youtube.com/@BryantCarter-z4y5e", icon: SiYoutube, color: "text-red-400", label: "YouTube" },
    { href: "https://www.instagram.com/degeneracy420", icon: SiInstagram, color: "text-pink-400", label: "Instagram" },
    { href: "https://x.com/Degeneracy420", icon: SiX, color: "text-blue-400", label: "X (Twitter)" },
    { href: "https://discord.gg/MM3bjatyun", icon: SiDiscord, color: "text-indigo-400", label: "Discord" },
  ];

  return (
    <footer className="bg-dark-surface border-t border-dark-border mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Social Icons */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-semibold text-text-primary mb-6">FOLLOW MY SOCIALS</h3>
          <div className="flex justify-center space-x-8">
            {socialLinks.map((social, index) => {
              const IconComponent = social.icon;
              return (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid={`social-${social.label.toLowerCase()}`}
                  className="w-16 h-16 glass-surface rounded-lg flex items-center justify-center hover:bg-primary-gold hover:scale-110 transition-all duration-300 group premium-card"
                  aria-label={social.label}
                >
                  <IconComponent className={`${social.color} text-2xl group-hover:text-dark-bg transition-colors`} />
                </a>
              );
            })}
          </div>
        </div>

        {/* Gambling Warning */}
        <div className="text-center">
          <div className="glass-surface rounded-lg p-6 mb-6 inline-block">
            <div className="flex items-center justify-center mb-3">
              <AlertTriangle className="text-yellow-400 mr-2 h-5 w-5" />
              <span className="text-sm font-medium text-yellow-400">Responsible Gaming</span>
            </div>
            <p className="text-sm text-text-secondary mb-4 leading-relaxed">
              Gambling can be addictive. Please play responsibly.
            </p>
            <a
              href="https://www.begambleaware.org/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="gambling-help-link"
              className="text-primary-gold hover:text-text-primary transition-colors duration-300 text-sm font-medium inline-flex items-center"
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              BeGambleAware.org
            </a>
          </div>
          
          <div className="border-t border-dark-border pt-6">
            <p className="text-text-secondary text-sm">© 2025 DEGENERACY. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}