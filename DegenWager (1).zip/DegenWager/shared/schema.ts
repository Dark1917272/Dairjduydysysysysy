import { z } from "zod";

export const wagerDataSchema = z.object({
  user: z.string(),
  wagered: z.number(),
  prize: z.number(),
  id: z.string().optional(),
  rank: z.number().optional(),
  bets: z.number().optional(),
});

export const leaderboardResponseSchema = z.object({
  data: z.array(wagerDataSchema),
  totalPlayers: z.number().optional(),
  totalWagered: z.number().optional(),
  totalPrizes: z.number().optional(),
});

export type WagerData = z.infer<typeof wagerDataSchema>;
export type LeaderboardResponse = z.infer<typeof leaderboardResponseSchema>;
