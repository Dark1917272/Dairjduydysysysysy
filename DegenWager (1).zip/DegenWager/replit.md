# RainBet Leaderboard Application

## Project Overview
A premium Node.js/Express web application that fetches and displays RainBet affiliate data in a stunning, modern glassmorphic leaderboard interface with advanced animations and high-quality visual effects.

## Recent Major Updates (Aug 6, 2025)

### 🔥 Home Page Fire Enhancement
- **Epic Background**: Added custom fire-themed background image with overlay effects
- **Fire Crackling Effects**: 20 animated fire particles and 15 spark particles with randomized physics
- **Platform Social Links**: Added all 5 platform links (Kick, Discord, YouTube, X, RainBet) with authentic icons
- **Flame Animations**: Rotating flame borders, crackling glow effects, and fire-themed transitions
- **Hero Transformation**: Enhanced logo to "DEGENERACY420" with fire emojis and crown/flame decorations

### 🎨 Premium Visual Enhancements
- **Enhanced Animations**: Added 15+ custom CSS animations including bounce-in effects, shimmer effects, rank glows, and avatar hover animations
- **Platform Icons**: Integrated react-icons/si for authentic platform detection (Discord, Kick, Twitch, YouTube, X/Twitter, Instagram, Telegram, Reddit)
- **Premium Avatars**: Upgraded to Dicebear API v8 with enhanced customization and premium styling
- **Floating Particles**: Added 25 animated gold particles floating in background for premium gaming aesthetic
- **Advanced Hover Effects**: Multi-layer hover animations with scale, glow, and color transitions

### 🏆 Leaderboard Improvements
- **Tier-Based Ranking**: Enhanced rank badges with different styles for ranks 1-3, 4-5, 6-10, and beyond
- **All Players Display**: Fixed limitation - now shows ALL players instead of just top 10
- **Premium Card Styling**: Enhanced top 3 player cards with staggered animations, tier-specific glows, and platform badges
- **Enhanced Table View**: Improved table design with gradient headers, enhanced hover effects, and detailed player info

### 🎯 Interactive Features
- **Smart Platform Detection**: Automatically detects and displays platform icons based on username patterns
- **Enhanced Stats Cards**: Added third stats card for "Potential Prizes" with premium styling
- **Premium Refresh Button**: Gradient button with loading states and hover animations
- **Live Data Display**: Enhanced date formatting and real-time update indicators

### 💎 Premium Design Elements
- **Glassmorphic Effects**: Enhanced glass surfaces with backdrop blur and gold accents
- **Gold Gradient System**: Consistent primary/secondary gold theming throughout
- **Advanced Shadows**: Multi-layer shadow system with color-coded glows
- **Responsive Typography**: Enhanced font weights, tracking, and hierarchy

## Architecture

### Frontend (React + TypeScript)
- **Framework**: Vite + React with TypeScript
- **UI Library**: shadcn/ui components with custom Tailwind CSS
- **State Management**: TanStack Query for data fetching
- **Styling**: Tailwind CSS with custom premium animations
- **Icons**: Lucide React + React Icons (Simple Icons)

### Backend (Node.js + Express)
- **API Integration**: RainBet affiliate API for live leaderboard data
- **Data Processing**: Real-time sorting and ranking calculation
- **Response Format**: Structured JSON with player statistics

### Enhanced Features
- **Real-time Data**: Live API integration with automatic refresh capability
- **Premium Animations**: 15+ custom CSS animations for professional gaming feel
- **Platform Integration**: Smart platform detection and icon display
- **Responsive Design**: Mobile-first approach with desktop enhancements

## User Preferences
- **Design Style**: Premium gaming aesthetic with gold accents and glassmorphic elements
- **Animations**: High-quality, smooth animations preferred over basic effects
- **Data Display**: Show all players, not limited subsets
- **Visual Quality**: Professional gaming website standard with advanced hover effects

## Development Guidelines
- Follow fullstack_js blueprint for consistent architecture
- Prioritize visual quality and smooth animations
- Use authentic platform data and icons
- Maintain responsive design principles
- Document major visual/architectural changes

## Key Files
- `client/src/pages/leaderboard.tsx` - Main leaderboard component with enhanced animations
- `client/src/index.css` - Custom CSS animations and premium styling
- `server/routes.ts` - RainBet API integration and data processing
- `shared/schema.ts` - TypeScript interfaces for data structure

## API Integration
- **RainBet API**: Live affiliate data fetching with real user data (62 active affiliates)
- **Date Range Limitation**: API requires max 4-month date ranges (resolved)
- **Real Usernames**: Gaming/crypto usernames like "DegenParadox", "z0mbie420" are authentic RainBet users
- **Authentic Data**: Wagering amounts ($142,597.80 top user) are real affiliate statistics
- **Dicebear API**: Premium avatar generation
- **Platform Detection**: Smart username-based platform icon assignment

## Future Enhancement Ideas
- Real-time WebSocket updates
- Player profile modals with detailed stats
- Achievement badges and milestones
- Leaderboard filters and sorting options
- Social sharing features