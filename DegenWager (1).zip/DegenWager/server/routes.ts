import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // RainBet API endpoint for affiliate wager data with time filtering
  app.get("/api/wagers/:timeFilter?", async (req, res) => {
    try {
      const apiKey = process.env.RAINBET_API_KEY || "SpMfoOLn7KGxIP9d1v4Z4THdlcChmOAE";
      const timeFilter = req.params.timeFilter || 'all';
      

      
      // Calculate date range based on time filter
      let startDate, endDate;
      const now = new Date();
      
      switch (timeFilter) {
        case 'day':
          startDate = new Date(now).toISOString().split('T')[0];
          endDate = startDate;
          break;
        case 'week':
          const weekAgo = new Date(now);
          weekAgo.setDate(weekAgo.getDate() - 7);
          startDate = weekAgo.toISOString().split('T')[0];
          endDate = now.toISOString().split('T')[0];
          break;
        case 'month':
          const monthAgo = new Date(now);
          monthAgo.setDate(monthAgo.getDate() - 30);
          startDate = monthAgo.toISOString().split('T')[0];
          endDate = now.toISOString().split('T')[0];
          break;
        default: // 'all'
          // Use maximum allowed range (4 months) for all time data
          const fourMonthsAgo = new Date(now);
          fourMonthsAgo.setMonth(fourMonthsAgo.getMonth() - 4);
          startDate = fourMonthsAgo.toISOString().split('T')[0];
          endDate = now.toISOString().split('T')[0];
      }
      
      const params = new URLSearchParams({
        start_at: startDate,
        end_at: endDate,
        key: apiKey
      });

      const url = `https://services.rainbet.com/v1/external/affiliates?${params}`;

      const response = await fetch(url);
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`RainBet API error: ${response.status} ${response.statusText} - ${errorText}`);
      }

      const data = await response.json();
      
      // Handle RainBet API response structure with affiliates array
      const affiliates = data.affiliates || [];
      let transformedData;
      
      if (Array.isArray(affiliates) && affiliates.length > 0) {
        // Sort by wagered amount (highest first)
        const sortedAffiliates = affiliates.sort((a: any, b: any) => 
          parseFloat(b.wagered_amount || 0) - parseFloat(a.wagered_amount || 0)
        );
        
        transformedData = {
          data: sortedAffiliates.map((item: any, index: number) => ({
            user: item.username || `Player_${index + 1}`,
            wagered: parseFloat(item.wagered_amount || 0),
            prize: parseFloat(item.wagered_amount || 0) * 0.1, // Calculate 10% as prize
            id: item.id || `player_${index + 1}`,
            rank: index + 1,
            bets: Math.floor(parseFloat(item.wagered_amount || 0) / 10) // Estimate bets
          })),
          totalPlayers: sortedAffiliates.length,
          totalWagered: sortedAffiliates.reduce((sum: number, item: any) => sum + parseFloat(item.wagered_amount || 0), 0),
          totalPrizes: sortedAffiliates.reduce((sum: number, item: any) => sum + parseFloat(item.wagered_amount || 0) * 0.1, 0)
        };
      } else {
        // Return empty data structure for display
        transformedData = {
          data: [],
          totalPlayers: 0,
          totalWagered: 0,
          totalPrizes: 0,
          message: "No leaderboard data available for today"
        };
      }

      res.json(transformedData);
    } catch (error) {
      console.error("Failed to fetch RainBet data:", error);
      
      // Check if it's a network or API error
      if (error instanceof Error) {
        if (error.message.includes('fetch') || error.message.includes('network')) {
          res.status(503).json({ 
            error: "Service temporarily unavailable",
            message: "Unable to connect to RainBet API. Please try again later."
          });
        } else if (error.message.includes('timeout')) {
          res.status(504).json({ 
            error: "Request timeout",
            message: "The request took too long to complete. Please try again."
          });
        } else {
          res.status(500).json({ 
            error: "Failed to fetch leaderboard data",
            message: error.message
          });
        }
      } else {
        res.status(500).json({ 
          error: "Internal server error",
          message: "An unexpected error occurred while fetching data"
        });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
