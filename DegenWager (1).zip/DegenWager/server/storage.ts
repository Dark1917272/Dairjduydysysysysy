import { type WagerData, type LeaderboardResponse } from "@shared/schema";
import { randomUUID } from "crypto";

// Storage interface for leaderboard data
export interface IStorage {
  getCachedLeaderboard(): Promise<LeaderboardResponse | undefined>;
  setCachedLeaderboard(data: LeaderboardResponse): Promise<void>;
  clearCache(): Promise<void>;
}

export class MemStorage implements IStorage {
  private cachedData: LeaderboardResponse | undefined;
  private cacheTimestamp: number | undefined;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  constructor() {
    this.cachedData = undefined;
    this.cacheTimestamp = undefined;
  }

  async getCachedLeaderboard(): Promise<LeaderboardResponse | undefined> {
    if (!this.cachedData || !this.cacheTimestamp) {
      return undefined;
    }
    
    const now = Date.now();
    if (now - this.cacheTimestamp > this.CACHE_DURATION) {
      this.cachedData = undefined;
      this.cacheTimestamp = undefined;
      return undefined;
    }
    
    return this.cachedData;
  }

  async setCachedLeaderboard(data: LeaderboardResponse): Promise<void> {
    this.cachedData = data;
    this.cacheTimestamp = Date.now();
  }

  async clearCache(): Promise<void> {
    this.cachedData = undefined;
    this.cacheTimestamp = undefined;
  }
}

export const storage = new MemStorage();
